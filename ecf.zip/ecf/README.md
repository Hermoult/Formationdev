OBJECTIFS A REALISER:
=====================

1. Initialiser le projet avec composer  / 2,5pts
2. Installer l'autoloader du psr-4      / 2,5pts
3. Importer le fichier ecf.sql dans une base de données que vous appelerez ecf  / 5pts
4. Dans brief/blog/model.php, réaliser ce qui est demandé en commentaire        / 20pts
5. Complétez PostManager.php, post.php, indexView.php et index.php              / 70pts



Vous rendrez votre projet ecf complété en renommant le répertoire ecf-votreprenom
Espace de rendu:
http://e-learning.alaji.fr/mod/assign/view.php?id=9517


