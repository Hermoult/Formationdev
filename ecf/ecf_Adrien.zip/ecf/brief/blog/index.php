<?php
require('model.php');

$req = getPosts();

require('indexView.php');
